package com.app.mybatis.config;

public class MybatisConfig {

}
